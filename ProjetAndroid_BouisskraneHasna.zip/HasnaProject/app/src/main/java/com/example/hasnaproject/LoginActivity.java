package com.example.hasnaproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private TextView textView;
    private EditText email;
    private EditText password;
    private Button login_btn;
    private TextView textViewRegister;

    MyDataBaseHelper dbH = new MyDataBaseHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);

        textView = findViewById(R.id.register_txt);
        login_btn = findViewById(R.id.login_btn);

        textViewRegister = (TextView) findViewById(R.id.register_txt);


        textViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId()==R.id.register_txt){
                    Intent intent =new Intent(LoginActivity.this,RegisterActivity.class);
                    startActivity(intent);}
            }});

        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailCheck = email.getText().toString();
                String passCheck = password.getText().toString();
                Cursor cursor = dbH.getData();
                if(cursor.getCount() == 0){
                    Toast.makeText(LoginActivity.this,"No entries Exists",Toast.LENGTH_LONG).show();
                }

                if (loginCheck(cursor,emailCheck,passCheck)) {
                    Intent intent = new Intent(LoginActivity.this,MenuActivity.class);
                    intent.putExtra("email",emailCheck);
                    email.setText("");
                    password.setText("");
                    startActivity(intent);
                }else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
                    builder.setCancelable(true);
                    builder.setTitle("Message");
                    builder.setMessage("Please try again");
                    builder.show();
                }
                dbH.close();
            }
        });
    }


    public static boolean loginCheck(Cursor cursor,String emailCheck,String passCheck) {
        while (cursor.moveToNext()){
            if (cursor.getString(2).equals(emailCheck)) {
                if (cursor.getString(4).equals(passCheck)) {
                    return true;
                }
                return false;
            }
        }
        return false;
    }
}