package com.example.hasnaproject;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class RegisterActivity extends AppCompatActivity {
   // private ImageButton imageButton;
    private EditText editTextRegisterFullName, editTextRegisterEmail, editTextRegisterMobile, editTextRegisterPassword, editTextRegisterMajor;
    private RadioGroup radioGroupRegisterGender;
    private RadioButton radioButtonRegisterGenderSelected;
    private Button buttonRegister;
    private TextView textViewLogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //imageButton = findViewById(R.id.img_btn);

        editTextRegisterFullName = (EditText) findViewById(R.id.editText_register_full_name);
        editTextRegisterEmail = (EditText) findViewById(R.id.editText_register_email);
        editTextRegisterMobile = (EditText) findViewById(R.id.editText_register_mobile);
        editTextRegisterPassword = (EditText) findViewById(R.id.editText_register_password);
        editTextRegisterMajor = (EditText) findViewById(R.id.editText_register_major);

        radioGroupRegisterGender = findViewById(R.id.radio_group_register_gender);
        radioGroupRegisterGender.clearCheck();

        buttonRegister = findViewById(R.id.btn_register);
        textViewLogin = (TextView) findViewById(R.id.textViewLinkLogin);


        MyDataBaseHelper db = new MyDataBaseHelper(this);
        textViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId()==R.id.textViewLinkLogin){
                    Intent intent =new Intent(RegisterActivity.this,LoginActivity.class);
                    startActivity(intent);}
            }});

        buttonRegister.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                int selectedGenderId = radioGroupRegisterGender.getCheckedRadioButtonId();
                radioButtonRegisterGenderSelected = findViewById(selectedGenderId);
                String textGender = radioButtonRegisterGenderSelected.getText().toString();
                String fullName = editTextRegisterFullName.getText().toString();
                String email = editTextRegisterEmail.getText().toString();
                String mobile = editTextRegisterMobile.getText().toString();
                String password = editTextRegisterPassword.getText().toString();
                String major = editTextRegisterMajor.getText().toString();


                 /*
                BitmapDrawable drawable = (BitmapDrawable) imageButton.getDrawable();
                Bitmap bitmap = drawable.getBitmap();
                byte[] image = getBytes(bitmap);*/


                if(TextUtils.isEmpty(fullName)){
                    Toast.makeText(RegisterActivity.this,"Please enter your name",Toast.LENGTH_LONG).show();
                    editTextRegisterFullName.setError("Name is required");
                    editTextRegisterFullName.requestFocus();

                }
                else if((TextUtils.isEmpty(fullName)) && (TextUtils.isEmpty(email)) && (TextUtils.isEmpty(major)) && (TextUtils.isEmpty(mobile)) && (radioGroupRegisterGender.getCheckedRadioButtonId()==-1) && (TextUtils.isEmpty(password))){
                    Toast.makeText(RegisterActivity.this,"All fields are required",Toast.LENGTH_LONG).show();
                    editTextRegisterFullName.setError("All fields are required");
                    editTextRegisterFullName.requestFocus();

                }else if (TextUtils.isEmpty(email)){
                    Toast.makeText(RegisterActivity.this,"Please enter your email",Toast.LENGTH_LONG).show();
                    editTextRegisterEmail.setError("Email is required");
                    editTextRegisterEmail.requestFocus();
                }else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    Toast.makeText(RegisterActivity.this,"Please re-enter your email",Toast.LENGTH_LONG).show();
                    editTextRegisterEmail.setError("Valid Email is required");
                    editTextRegisterEmail.requestFocus();
                }else if(TextUtils.isEmpty(major)){
                    Toast.makeText(RegisterActivity.this,"Please enter your Major",Toast.LENGTH_LONG).show();
                    editTextRegisterMajor.setError("Major is required");
                    editTextRegisterMajor.requestFocus();
                }else if(TextUtils.isEmpty(mobile)){
                    Toast.makeText(RegisterActivity.this,"Please enter your phone number",Toast.LENGTH_LONG).show();
                    editTextRegisterMobile.setError("Phone number is required");
                    editTextRegisterMobile.requestFocus();
                }else if(mobile.length() != 10){
                    Toast.makeText(RegisterActivity.this,"Please enter your phone number",Toast.LENGTH_LONG).show();
                    editTextRegisterMobile.setError("Phone number should be 10 digits");
                    editTextRegisterMobile.requestFocus();
                }
                 else if(TextUtils.isEmpty(password)){
                 Toast.makeText(RegisterActivity.this,"Please enter your password",Toast.LENGTH_LONG).show();
                    editTextRegisterPassword.setError("Password is required");
                    editTextRegisterPassword.requestFocus();
                 }else if(password.length() > 8)
                {
                    Toast.makeText(RegisterActivity.this,"Password should be at least 8 digits",Toast.LENGTH_LONG).show();
                    editTextRegisterPassword.setError("Password too long");
                    editTextRegisterPassword.requestFocus();
                }else {
                 Toast.makeText(RegisterActivity.this,"Data saved successfully",Toast.LENGTH_LONG).show();

             }


                User person = new User(fullName, email, mobile, password, major, textGender,null);

                db.addPerson(person);
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }


        });
    }
   /* public void openGallerie(View view){
        Intent intentImg = new Intent(Intent.ACTION_GET_CONTENT);
        intentImg.setType("image/*");
        startActivityForResult(intentImg, 100);
    }*/
    /*
    //intentImage
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && requestCode == 100){
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap decodeStream = BitmapFactory.decodeStream(inputStream);
                imageButton.setImageBitmap(decodeStream);
            }catch (Exception e){
                Log.e("Error",e.getMessage());
            }
        }
    }
    public static byte[] getBytes(Bitmap bitmap){
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
        return stream.toByteArray();
    }*/
}