package com.example.hasnaproject;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class UpdateActivity extends AppCompatActivity {
    private ImageButton imageButton;
    private EditText editTextUpdateFullName, editTextUpdateEmail, editTextUpdateMobile, editTextUpdatePassword, editTextUpdateMajor,editTextUpdateGender;
    private RadioGroup radioGroupUpdateGender;
    private RadioButton radioButtonUpdateGenderSelected;
    private Button buttonUpdate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        imageButton = findViewById(R.id.img_btn_update);

        editTextUpdateFullName = (EditText) findViewById(R.id.editText_register_full_name_update);
        editTextUpdateEmail = (EditText) findViewById(R.id.editText_register_email_update);
        editTextUpdateMobile = (EditText) findViewById(R.id.editText_register_mobile_update);
        editTextUpdatePassword = (EditText) findViewById(R.id.editText_register_password_update);
        editTextUpdateMajor = (EditText) findViewById(R.id.editText_register_major_update);

        radioGroupUpdateGender = findViewById(R.id.radio_group_register_gender_update);
        radioGroupUpdateGender.clearCheck();

        buttonUpdate = findViewById(R.id.idBtnUpdate);

        MyDataBaseHelper db = new MyDataBaseHelper(this);
        Cursor cursor = db.getData();
        while (cursor.moveToNext()){
            editTextUpdateFullName.setText(cursor.getString(1));
            editTextUpdateEmail.setText(cursor.getString(2));
            editTextUpdateMobile.setText(cursor.getString(3));
            editTextUpdatePassword.setText(cursor.getString(4));
            editTextUpdateMajor.setText(cursor.getString(5));

        }


        buttonUpdate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String fullName = editTextUpdateFullName.getText().toString();
                String email = editTextUpdateEmail.getText().toString();
                String mobile = editTextUpdateMobile.getText().toString();
                String password = editTextUpdatePassword.getText().toString();
                String major = editTextUpdateMajor.getText().toString();

                int selectedGenderId = radioGroupUpdateGender.getCheckedRadioButtonId();
                Log.e("id", String.valueOf(selectedGenderId));
                radioButtonUpdateGenderSelected = findViewById(selectedGenderId);
                String textGender = radioButtonUpdateGenderSelected.getText().toString();

                if(TextUtils.isEmpty(fullName)){
                    Toast.makeText(UpdateActivity.this,"your name",Toast.LENGTH_LONG).show();
                    editTextUpdateFullName.setError("Name is required");
                    editTextUpdateFullName.requestFocus();

                }else if (TextUtils.isEmpty(email)){
                    Toast.makeText(UpdateActivity.this,"Please enter your email",Toast.LENGTH_LONG).show();
                    editTextUpdateEmail.setError("Email is required");
                    editTextUpdateEmail.requestFocus();
                }else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    Toast.makeText(UpdateActivity.this,"Please re-enter your email",Toast.LENGTH_LONG).show();
                    editTextUpdateEmail.setError("Valid Email is required");
                    editTextUpdateEmail.requestFocus();
                }else if(TextUtils.isEmpty(major)){
                    Toast.makeText(UpdateActivity.this,"Please enter your Major",Toast.LENGTH_LONG).show();
                    editTextUpdateMajor.setError("Major is required");
                    editTextUpdateMajor.requestFocus();
                }else if(TextUtils.isEmpty(mobile)){
                    Toast.makeText(UpdateActivity.this,"Please enter your phone number",Toast.LENGTH_LONG).show();
                    editTextUpdateMobile.setError("Phone number is required");
                    editTextUpdateMobile.requestFocus();
                }else if(mobile.length() != 10){
                    Toast.makeText(UpdateActivity.this,"Please enter your phone number",Toast.LENGTH_LONG).show();
                    editTextUpdateMobile.setError("Phone number should be 10 digits");
                    editTextUpdateMobile.requestFocus();
                }
                else if(TextUtils.isEmpty(password)){
                    Toast.makeText(UpdateActivity.this,"Please enter your password",Toast.LENGTH_LONG).show();
                    editTextUpdatePassword.setError("Password is required");
                    editTextUpdatePassword.requestFocus();
                }else if(password.length() > 8)
                {
                    Toast.makeText(UpdateActivity.this,"Password should be at least 8 digits",Toast.LENGTH_LONG).show();
                    editTextUpdatePassword.setError("Password too long");
                    editTextUpdatePassword.requestFocus();
                }else {
                    Toast.makeText(UpdateActivity.this,"Data updated successfully",Toast.LENGTH_LONG).show();

                }



                BitmapDrawable drawable = (BitmapDrawable) imageButton.getDrawable();
                Bitmap bitmap = drawable.getBitmap();
                byte[] image = getBytes(bitmap);

                User person = new User(fullName, email, mobile, password, major, textGender,image);

                db.updateProfile(person);
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }


        });
    }
    public void openGallerie(View view){
        Intent intentImg = new Intent(Intent.ACTION_GET_CONTENT);
        intentImg.setType("image/*");
        startActivityForResult(intentImg, 100);
    }
    //recevoir les résultats retournés par intentImg
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && requestCode == 100){
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap decodeStream = BitmapFactory.decodeStream(inputStream);
                imageButton.setImageBitmap(decodeStream);
            }catch (Exception e){
                Log.e("Error",e.getMessage());
            }
        }
    }
    public static byte[] getBytes(Bitmap bitmap){
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
        return stream.toByteArray();
    }

}