package com.example.hasnaproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MenuActivity extends AppCompatActivity {

    LinearLayout l1,l2;
    Animation uptodown,downtoup;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        btn1 = (Button)findViewById(R.id.btn1);
        l1 = (LinearLayout) findViewById(R.id.ll1);
        l2 = (LinearLayout) findViewById(R.id.ll2);
        uptodown = AnimationUtils.loadAnimation(this,R.anim.uptodown);
        downtoup = AnimationUtils.loadAnimation(this,R.anim.downtoup);
        l1.setAnimation(uptodown);
        l2.setAnimation(downtoup);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MenuActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.navigation_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    // override the onOptionsItemSelected()
    // function to implement
    // the item click listener callback
    // to open and close the navigation
    // drawer when the icon is clicked
    @Override



    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id =item.getItemId();


           if (id==R.id.nav_profile){
               Toast.makeText(MenuActivity.this,"Your profile",Toast.LENGTH_LONG).show();

               Intent intent =new Intent(MenuActivity.this,UpdateActivity.class);
                startActivity(intent);
            }else if (id==R.id.nav_location){
               Toast.makeText(MenuActivity.this,"Your location",Toast.LENGTH_LONG).show();

               Intent intent =new Intent(MenuActivity.this,GmapActivity.class);
            startActivity(intent);
        }else if (id==R.id.nav_activities){
               Toast.makeText(MenuActivity.this,"your activities",Toast.LENGTH_LONG).show();

               Intent intent =new Intent(MenuActivity.this,MyactActivity.class);
            startActivity(intent);
        }else if (id==R.id.nav_logout){
                // signOut();
                Toast.makeText(MenuActivity.this,"Logged Out",Toast.LENGTH_LONG).show();
                Intent intent=new Intent(MenuActivity.this,MainActivity.class);

                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NEW_TASK );
                startActivity(intent);
                finish();
            }else {
                Toast.makeText(MenuActivity.this,"Something went wrong",Toast.LENGTH_LONG).show();

            }

        return super.onOptionsItemSelected(item);
    }
}