package com.example.hasnaproject;

public class User {
    private int id;
    private String fullName;
    private String email;
    private String mobile;
    private String password;
    private String major;
    private String gender;
    private byte[] image;
/*
    public User(int id, String fullName, String email, String mobile, String password, String major, String gender, byte[] image) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.mobile = mobile;
        this.password = password;
        this.major = major;
        this.gender = gender;
        this.image = image;
    }
*/
    public User(String fullName, String email, String mobile, String password, String major, String gender, byte[] image) {
        this.fullName = fullName;
        this.email = email;
        this.mobile = mobile;
        this.password = password;
        this.major = major;
        this.gender = gender;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }

    public String getMobile() {
        return mobile;
    }

    public String getPassword() {
        return password;
    }

    public String getMajor() {
        return major;
    }

    public String getGender() {
        return gender;
    }

    public byte[] getImage() {
        return image;
    }
}